// all javascript files related to themes should be require in this manifest.
//= require modernizr.custom
//= require bootstrap-number-input
//= require navbar
//= require custom
//= require jquery.jInvertScroll
