// all javascript files related to themes should be require in this manifest.
//= require lib/jquery.bxslider-rahisified
//= require sliders
//= require mobile-views
